﻿using System;
using System.Collections.Generic;
<<<<<<< HEAD
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using Luxury_Shop.Models;
=======

>>>>>>> ed2591fd72ac017a0f7e3a80236d9cae49d724dd

namespace Luxury_Shop.Controllers
{
    public class ProductsController : Controller
    {
<<<<<<< HEAD
      

=======
        // GET: Products
        
    }
}
>>>>>>> ed2591fd72ac017a0f7e3a80236d9cae49d724dd
